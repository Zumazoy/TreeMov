import 'package:treemov/features/teacher_calendar/data/models/schedule_response_model.dart';
import 'package:treemov/features/teacher_calendar/data/models/schedule_update_model.dart';
import 'package:treemov/features/teacher_calendar/domain/repositories/schedule_repository.dart';

class UpdateScheduleUsecase {
  final ScheduleRepository _repository;

  UpdateScheduleUsecase(this._repository);

  Future<ScheduleResponseModel> execute({
    required int scheduleId,
    required ScheduleUpdateModel updateData,
  }) async {
    return await _repository.updateSchedule(
      scheduleId: scheduleId,
      updateData: updateData,
    );
  }
}
