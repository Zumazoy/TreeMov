class SubjectEntity {
  final String id;
  final String name;

  const SubjectEntity({required this.id, required this.name});
}
