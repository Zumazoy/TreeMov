import 'package:flutter/material.dart';

import '../../themes/app_colors.dart';

class CustomBottomNavigationBar extends StatelessWidget {
  final int currentIndex;
  final Function(int) onTap;

  const CustomBottomNavigationBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final unselectedColor = AppColors.grey;
    final selectedColor = AppColors.plusButton;

    return BottomNavigationBar(
      currentIndex: currentIndex,
      onTap: onTap,
      type: BottomNavigationBarType.fixed,
      backgroundColor: AppColors.white,
      selectedItemColor: selectedColor,
      unselectedItemColor: unselectedColor,
      selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500),
      showSelectedLabels: true,
      showUnselectedLabels: true,

      items: [
        BottomNavigationBarItem(
          icon: Image.asset(
            'assets/images/calendar_icon.png',
            width: 24,
            height: 24,
            color: unselectedColor,
          ),
          activeIcon: Image.asset(
            'assets/images/calendar_icon.png',
            width: 24,
            height: 24,
            color: selectedColor,
          ),
          label: 'Календарь',
        ),
        BottomNavigationBarItem(
          icon: Image.asset(
            'assets/images/leaderboard_icon.png',
            width: 24,
            height: 24,
            color: unselectedColor,
          ),
          activeIcon: Image.asset(
            'assets/images/leaderboard_icon.png',
            width: 24,
            height: 24,
            color: selectedColor,
          ),
          label: 'Рейтинг',
        ),
        BottomNavigationBarItem(
          icon: Image.asset(
            'assets/images/shop_icon.png',
            width: 24,
            height: 24,
            color: unselectedColor,
          ),
          activeIcon: Image.asset(
            'assets/images/shop_icon.png',
            width: 24,
            height: 24,
            color: selectedColor,
          ),
          label: 'Справка',
        ),
        BottomNavigationBarItem(
          icon: Image.asset(
            'assets/images/tree_profile.png',
            width: 24,
            height: 24,
            color: unselectedColor,
          ),
          activeIcon: Image.asset(
            'assets/images/tree_profile.png',
            width: 24,
            height: 24,
            color: selectedColor,
          ),
          label: 'Профиль',
        ),
      ],
    );
  }
}
